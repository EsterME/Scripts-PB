papers <- read.csv("papers1269new.csv", header=T)
names(papers)
summary(papers)

papers$bina <- array(NA,length(papers$binary))
for (i in 1:length(papers$binary)) {
	if (papers$binary[i]=="yes") {
	papers$bina[i] <- 1
	} else {
	papers$bina[i] <- 0
	}
}

modelYN <- glm(binary~SO+PY+log(TC+1), data=papers, family=binomial)
summary(modelYN)
library(car)
Anova(modelYN)

plot(binary~as.factor(PY), data=papers, xlab="year", ylab="data accessibility")
plot(binary~log(TC+1), data=papers, xlab="number of citations")

library(gam)
TC.PY <- gam(TC~PY, data=papers)
plot(TC~PY, data=papers)
hist(TC.PY$res)
head(TC.PY$res,15)

TC.PY.res <-cbind(row.names(as.data.frame(TC.PY$res)),as.data.frame(TC.PY$res))
dim(TC.PY.res)
names(TC.PY.res)
names(TC.PY.res) <- c("ordered","citation_residuals")
names(TC.PY.res)

papers2 <- merge(papers,TC.PY.res,"ordered")

modelYN2 <- glm(binary~SO+PY+citation_residuals, data=papers2, family=binomial)
summary(modelYN2)
library(car)
Anova(modelYN2)


par(mfrow=c(1,3))
plot(binary~SO, data=papers2)
plot(binary~PY, data=papers2)
plot(binary~citation_residuals, data=papers2)

par(mfrow=c(1,3))
plot(bina~SO, data=papers2)
plot(bina~PY, data=papers2)
plot(bina~citation_residuals, data=papers2)


papers3 <- droplevels(subset(papers, Repository=="MG-RAST"|Repository=="NCBI/ENA/DDBJ", select=c(Repository,binary)))
repo <- table(papers3$Repository, papers3$binary)
chisq.test(repo)
plot(repo)





