j76 <- read.csv("journal76.csv", header=T)
names(j76)

par(las=2, mai=c(3.2,1,0.2,0.2))
ord <- ordered(j76$field, levels=c("Biochemistry & Molecular Biology","Ecology","Genetics & Heredity","Infectious Diseases","Microbiology","Virology","Multidisciplinary Sciences","Biotechnology & Applied Microbiology","Environmental Engineering","Environmental Sciences","Food Science & Technology"))
plot((1-j76$no/j76$total)~ord, xlab="", ylab="proportion of accessible data", col="lightgrey")

library(lme4)
model0 <- glmer(cbind(no,total)~field+(1|source), family=binomial, data=j76)
summary(model0)
library(car)
Anova(model0)




j59 <- read.csv("journal59new.csv", header=T)
names(j59)
j59$age <- 2019-j59$year
j59$IFL <- log(j59$IF)
j59$ageL <- log(j59$age)
j59$papersL <- log(j59$papers)
names(j59)

library(psych)
pairs.panels(j59[,c(7,8,11,14,15,16)])

model1 <- glm(cbind(no,total)~openAccess+BMT+log(IF)+log(age)+log(papers)+editor, family=binomial, data=j59)
summary(model1)
library(car)
Anova(model1)

par(mfrow=c(1,2))
plot((1-j59$no/j59$total)~j59$openAccess, xlab="Open Access", ylab="proportion of accessible data", col="lightgrey")
plot((1-j59$no/j59$total)~j59$BMT, xlab="Type of scientific field", ylab="proportion of accessible data", col="lightgrey")

plot((1-j59$no/j59$total)~j59$IF, xlab="Impact Factor", ylab="proportion of accessible data", col="blue",log="x")

par(mai=c(4.5,1,0.1,0.1))
plot((1-j59$no/j59$total)~j59$editor, las=2, xlab="", ylab="proportion of accessible data", col="lightgrey")



prop <- 1-j59$no/j59$total
z <- lm(prop~j59$IF)
plot(prop~j59$IF, las=2, xlab="Impact Factor", ylab="proportion of accessible data")
abline(z)

zL <- lm(prop~j59$IFL)
plot(prop~j59$IFL, las=2, xlab="Impact Factor - log", ylab="proportion of accessible data")
abline(zL)

z <- lm(prop~j59$papers)
plot(prop~j59$papers, las=2, xlab="number of papers", ylab="proportion of accessible data")
abline(z)

zL <- lm(prop~j59$papersL)
plot(prop~j59$papersL, las=2, xlab="number of papers - log", ylab="proportion of accessible data")
abline(zL)

